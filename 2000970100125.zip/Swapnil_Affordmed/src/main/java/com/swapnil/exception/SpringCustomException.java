package com.swapnil.exception;

public class SpringCustomException {
}
