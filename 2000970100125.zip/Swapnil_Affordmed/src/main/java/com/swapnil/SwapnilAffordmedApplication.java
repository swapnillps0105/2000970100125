package com.swapnil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwapnilAffordmedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwapnilAffordmedApplication.class, args);
	}

}
